import { useUser } from "@/hooks/use-auth";
import { useContent } from "@/hooks/use-content";
import Navbar from "@/components/layout/Navbar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ClientDashboard() {
  const { data: user } = useUser();
  const { data: allContent, isLoading } = useContent();
  
  // In a real app, backend would filter this. Here we filter client-side for demo.
  // Assuming user.id matches content.clientId for this simulation.
  const myContent = allContent?.filter(c => c.clientId === user?.id) || [];

  if (user?.role !== "client" && user?.role !== "admin") return <div>Unauthorized</div>;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-display font-bold mb-2">Welcome, {user?.username}</h1>
        <p className="text-muted-foreground mb-8">Here are your project deliverables.</p>

        {isLoading ? <Loader2 className="animate-spin" /> : (
          <Tabs defaultValue="all" className="space-y-6">
            <TabsList>
              <TabsTrigger value="all">All Files</TabsTrigger>
              <TabsTrigger value="image">Images</TabsTrigger>
              <TabsTrigger value="video">Videos</TabsTrigger>
              <TabsTrigger value="audio">Audio</TabsTrigger>
            </TabsList>

            {["all", "image", "video", "audio"].map(type => (
              <TabsContent key={type} value={type}>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {myContent
                    .filter(c => type === "all" || c.type === type)
                    .map(item => (
                    <Card key={item.id} className="overflow-hidden group">
                      <div className="aspect-video bg-gray-100 relative flex items-center justify-center">
                        {item.type === 'image' && <img src={item.url} className="w-full h-full object-cover" />}
                        {item.type === 'video' && <video src={item.url} controls className="w-full h-full object-cover" />}
                        {item.type === 'audio' && <audio src={item.url} controls className="w-full" />}
                      </div>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">{item.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-4">{item.description || "No description provided."}</p>
                        <Button variant="outline" className="w-full gap-2" asChild>
                          <a href={item.url} target="_blank" download>
                            <Download className="h-4 w-4" /> Download
                          </a>
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                  {myContent.length === 0 && (
                    <div className="col-span-3 text-center py-12 text-muted-foreground border-2 border-dashed rounded-lg">
                      No deliverables uploaded yet.
                    </div>
                  )}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        )}
      </div>
    </div>
  );
}
