import { useUser } from "@/hooks/use-auth";
import { useInquiries } from "@/hooks/use-inquiries";
import { useConfig, useUpdateConfig } from "@/hooks/use-config";
import Navbar from "@/components/layout/Navbar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2, Save } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function AdminDashboard() {
  const { data: user } = useUser();
  const { data: inquiries, isLoading: loadingInquiries } = useInquiries();
  const { data: config, isLoading: loadingConfig } = useConfig();
  const { mutate: updateConfig } = useUpdateConfig();
  const { toast } = useToast();
  
  const [configForm, setConfigForm] = useState<Record<string, string>>({});

  if (user?.role !== "admin") return <div>Unauthorized</div>;

  const handleConfigUpdate = (key: string, value: string) => {
    updateConfig({ key, value }, {
      onSuccess: () => toast({ title: "Updated", description: `Config for ${key} saved.` })
    });
  };

  return (
    <div className="min-h-screen bg-muted/10">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-display font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage your site content, inquiries, and settings.</p>
        </div>

        <Tabs defaultValue="inquiries" className="space-y-6">
          <TabsList className="bg-white border">
            <TabsTrigger value="inquiries">Inquiries</TabsTrigger>
            <TabsTrigger value="config">Site Config (CMS)</TabsTrigger>
          </TabsList>

          <TabsContent value="inquiries">
            <Card>
              <CardHeader>
                <CardTitle>Recent Messages</CardTitle>
              </CardHeader>
              <CardContent>
                {loadingInquiries ? <Loader2 className="animate-spin" /> : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Message</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {inquiries?.map(i => (
                        <TableRow key={i.id}>
                          <TableCell className="font-medium">{i.name}</TableCell>
                          <TableCell>{i.email}</TableCell>
                          <TableCell className="capitalize">{i.type}</TableCell>
                          <TableCell className="max-w-xs truncate" title={i.message}>{i.message}</TableCell>
                          <TableCell>{new Date(i.createdAt || "").toLocaleDateString()}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="config">
            <Card>
              <CardHeader>
                <CardTitle>Content Management System</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {loadingConfig ? <Loader2 className="animate-spin" /> : (
                  config?.map(c => (
                    <div key={c.id} className="flex gap-4 items-center p-4 border rounded-lg bg-white">
                      <div className="w-1/3">
                        <span className="font-semibold text-sm uppercase text-muted-foreground">{c.key.replace("_", " ")}</span>
                      </div>
                      <div className="flex-1 flex gap-2">
                        <Input 
                          defaultValue={c.value} 
                          onChange={(e) => setConfigForm(prev => ({ ...prev, [c.key]: e.target.value }))} 
                        />
                        <Button 
                          size="icon" 
                          variant="outline"
                          onClick={() => handleConfigUpdate(c.key, configForm[c.key] || c.value)}
                        >
                          <Save className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
                {/* Mock Add Config UI */}
                <div className="p-4 border border-dashed rounded-lg text-center text-muted-foreground">
                  + Add New Configuration Key
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
