import { useUser } from "@/hooks/use-auth";
import { useContent, useCreateContent, useDeleteContent } from "@/hooks/use-content";
import Navbar from "@/components/layout/Navbar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Trash2, Loader2, Upload } from "lucide-react";

export default function ManagerDashboard() {
  const { data: user } = useUser();
  const { data: content, isLoading } = useContent();
  const { mutate: createContent, isPending } = useCreateContent();
  const { mutate: deleteContent } = useDeleteContent();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    clientId: "",
    title: "",
    type: "image" as "image" | "audio" | "video",
    url: "",
    description: ""
  });

  if (user?.role !== "manager" && user?.role !== "admin") return <div>Unauthorized</div>;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    createContent({
      ...formData,
      clientId: parseInt(formData.clientId), // In real app, select from list of clients
      managerId: user.id
    }, {
      onSuccess: () => {
        toast({ title: "Uploaded", description: "Content added successfully." });
        setFormData({ clientId: "", title: "", type: "image", url: "", description: "" });
      }
    });
  };

  return (
    <div className="min-h-screen bg-muted/10">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-display font-bold mb-8">Manager Portal</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Upload Form */}
          <Card className="lg:col-span-1 h-fit">
            <CardHeader>
              <CardTitle>Upload Content</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <Input 
                  placeholder="Client ID (e.g., 5)" 
                  value={formData.clientId}
                  onChange={e => setFormData({...formData, clientId: e.target.value})}
                  required
                  type="number"
                />
                <Input 
                  placeholder="Title" 
                  value={formData.title}
                  onChange={e => setFormData({...formData, title: e.target.value})}
                  required
                />
                <Select 
                  value={formData.type} 
                  onValueChange={(val: any) => setFormData({...formData, type: val})}
                >
                  <SelectTrigger><SelectValue placeholder="Type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="image">Image</SelectItem>
                    <SelectItem value="video">Video</SelectItem>
                    <SelectItem value="audio">Audio</SelectItem>
                  </SelectContent>
                </Select>
                <Input 
                  placeholder="Content URL" 
                  value={formData.url}
                  onChange={e => setFormData({...formData, url: e.target.value})}
                  required
                />
                <Input 
                  placeholder="Description" 
                  value={formData.description}
                  onChange={e => setFormData({...formData, description: e.target.value})}
                />
                <Button type="submit" className="w-full" disabled={isPending}>
                  {isPending ? <Loader2 className="animate-spin mr-2" /> : <Upload className="mr-2 h-4 w-4" />}
                  Upload
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Content List */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Manage Uploads</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? <Loader2 className="animate-spin" /> : (
                <div className="space-y-4">
                  {content?.map(item => (
                    <div key={item.id} className="flex items-center justify-between p-4 border rounded-lg bg-white shadow-sm">
                      <div className="flex items-center gap-4">
                        <div className="h-12 w-12 bg-gray-100 rounded flex items-center justify-center overflow-hidden">
                          {item.type === 'image' && <img src={item.url} className="w-full h-full object-cover" />}
                          {item.type !== 'image' && <span className="uppercase text-xs font-bold">{item.type}</span>}
                        </div>
                        <div>
                          <p className="font-semibold">{item.title}</p>
                          <p className="text-xs text-muted-foreground">Client ID: {item.clientId}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteContent(item.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  {(!content || content.length === 0) && <p className="text-center text-muted-foreground">No content uploaded.</p>}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
