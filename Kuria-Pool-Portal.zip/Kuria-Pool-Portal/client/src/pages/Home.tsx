import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import HeroCarousel from "@/components/ui/HeroCarousel";
import Chatbot from "@/components/ui/Chatbot";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useServices } from "@/hooks/use-services";
import { useCreateInquiry } from "@/hooks/use-inquiries";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertInquirySchema, type InsertInquiry } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

export default function Home() {
  const { data: services, isLoading } = useServices();
  const { mutate: createInquiry, isPending } = useCreateInquiry();
  const { toast } = useToast();

  const form = useForm<InsertInquiry>({
    resolver: zodResolver(insertInquirySchema),
    defaultValues: { name: "", email: "", message: "", type: "contact" }
  });

  const onSubmit = (data: InsertInquiry) => {
    createInquiry(data, {
      onSuccess: () => {
        toast({ title: "Message Sent", description: "We'll get back to you soon." });
        form.reset();
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to send message.", variant: "destructive" });
      }
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        <HeroCarousel />

        {/* Services Section */}
        <section id="services" className="py-24 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <span className="text-primary uppercase tracking-widest font-semibold text-sm">Our Expertise</span>
              <h2 className="text-4xl md:text-5xl font-display font-bold mt-2">Premium Services</h2>
              <div className="w-24 h-1 bg-primary mx-auto mt-6" />
            </div>

            {isLoading ? (
              <div className="flex justify-center p-12"><Loader2 className="animate-spin h-8 w-8 text-primary" /></div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {services?.map((service) => (
                  <Card key={service.id} className="group overflow-hidden border-none shadow-lg hover:shadow-xl transition-all duration-300">
                    <div className="relative h-64 overflow-hidden">
                      <img 
                        src={service.imageUrl} 
                        alt={service.title} 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors" />
                    </div>
                    <CardHeader>
                      <CardTitle className="font-display text-xl">{service.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground line-clamp-2">{service.description}</p>
                    </CardContent>
                    <CardFooter className="flex justify-between items-center">
                      <span className="font-bold text-lg text-primary">₹{(service.price / 100).toLocaleString()}</span>
                      <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white">
                        Book Now
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
                {(!services || services.length === 0) && (
                   <p className="col-span-3 text-center text-muted-foreground">No services available at the moment.</p>
                )}
              </div>
            )}
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-24 bg-white">
          <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div className="order-2 md:order-1 relative">
              <div className="absolute -top-4 -left-4 w-full h-full border-2 border-primary" />
              <img 
                src="https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=800&q=80" 
                alt="Our Team" 
                className="relative z-10 w-full h-auto shadow-2xl"
              />
            </div>
            <div className="order-1 md:order-2 space-y-6">
              <h2 className="text-4xl font-display font-bold">Crafting Digital Excellence</h2>
              <p className="text-lg text-gray-600 leading-relaxed">
                Kuria Pool is more than just a freelancer portal; it's a curated ecosystem of top-tier talent. 
                Inspired by the elegance of high fashion, we bring the same attention to detail to web development 
                and digital services.
              </p>
              <div className="grid grid-cols-2 gap-8 pt-4">
                <div>
                  <h3 className="text-3xl font-bold text-primary">100+</h3>
                  <p className="text-sm text-gray-500 uppercase tracking-wider">Happy Clients</p>
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-primary">500+</h3>
                  <p className="text-sm text-gray-500 uppercase tracking-wider">Projects Done</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-24 bg-secondary text-secondary-foreground relative">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center mb-16">
              <h2 className="text-3xl font-display font-bold text-white mb-4">Get in Touch</h2>
              <p className="text-gray-400">Have a project in mind? Let's discuss how we can bring your vision to life.</p>
            </div>
            
            <Card className="max-w-md mx-auto bg-white/5 border-white/10 backdrop-blur-sm">
              <CardContent className="pt-6">
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div>
                    <Input 
                      placeholder="Your Name" 
                      {...form.register("name")} 
                      className="bg-white/10 border-white/20 text-white placeholder:text-gray-500"
                    />
                  </div>
                  <div>
                    <Input 
                      type="email" 
                      placeholder="Email Address" 
                      {...form.register("email")}
                      className="bg-white/10 border-white/20 text-white placeholder:text-gray-500"
                    />
                  </div>
                  <div>
                    <Textarea 
                      placeholder="Your Message" 
                      rows={4} 
                      {...form.register("message")}
                      className="bg-white/10 border-white/20 text-white placeholder:text-gray-500"
                    />
                  </div>
                  <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-black font-semibold" disabled={isPending}>
                    {isPending ? "Sending..." : "Send Message"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <Chatbot />
      <Footer />
    </div>
  );
}
