import { useUser } from "@/hooks/use-auth";
import { useBookings, useCreateBooking } from "@/hooks/use-bookings";
import { useServices } from "@/hooks/use-services";
import Navbar from "@/components/layout/Navbar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, Calendar } from "lucide-react";
import { format } from "date-fns";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function UserDashboard() {
  const { data: user } = useUser();
  const { data: bookings, isLoading: bookingsLoading } = useBookings();
  const { data: services } = useServices();
  const { mutate: createBooking, isPending } = useCreateBooking();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);

  // Filter bookings for this user
  const myBookings = bookings?.filter(b => b.userId === user?.id) || [];

  if (!user) return <div>Unauthorized</div>;

  const handleBooking = (serviceId: number) => {
    // Simulate Razorpay Payment Flow
    toast({ title: "Processing Payment...", description: "Connecting to Razorpay Gateway." });
    
    setTimeout(() => {
      createBooking({
        userId: user.id,
        serviceId,
        status: "confirmed",
        paymentStatus: "paid",
        bookingDate: new Date() // Just for demo
      }, {
        onSuccess: () => {
          toast({ title: "Success", description: "Service booked successfully!" });
          setOpen(false);
        }
      });
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-display font-bold">My Bookings</h1>
            <p className="text-muted-foreground">View your service history.</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button>Book New Service</Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader><DialogTitle>Select a Service</DialogTitle></DialogHeader>
              <div className="grid gap-4 mt-4">
                {services?.map(s => (
                  <div key={s.id} className="flex justify-between items-center p-4 border rounded-lg hover:border-primary transition-colors">
                    <div>
                      <h4 className="font-bold">{s.title}</h4>
                      <p className="text-sm text-muted-foreground">{s.category} • ₹{(s.price/100).toLocaleString()}</p>
                    </div>
                    <Button onClick={() => handleBooking(s.id)} disabled={isPending}>
                      {isPending ? "Processing..." : "Pay & Book"}
                    </Button>
                  </div>
                ))}
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {bookingsLoading ? <Loader2 className="animate-spin" /> : (
          <div className="space-y-4">
            {myBookings.map(b => (
              <Card key={b.id}>
                <CardContent className="flex justify-between items-center py-6">
                  <div className="flex items-center gap-4">
                    <div className="h-10 w-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <Calendar className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-bold">Booking #{b.id}</h4>
                      <p className="text-sm text-muted-foreground">
                        {b.bookingDate ? format(new Date(b.bookingDate), 'PPP') : 'Date not set'}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`
                      inline-flex px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide
                      ${b.status === 'confirmed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}
                    `}>
                      {b.status}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{b.paymentStatus}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
            {myBookings.length === 0 && (
              <p className="text-center py-12 text-muted-foreground">You haven't booked any services yet.</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
