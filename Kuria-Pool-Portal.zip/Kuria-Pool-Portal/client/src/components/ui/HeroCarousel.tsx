import useEmblaCarousel from "embla-carousel-react";
import Autoplay from "embla-carousel-autoplay";
import { Button } from "./button";

const SLIDES = [
  {
    image: "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?w=1920&h=1080&fit=crop",
    title: "Elevate Your Digital Presence",
    subtitle: "Premium freelance services for the modern entrepreneur."
  },
  {
    image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1920&h=1080&fit=crop",
    title: "Expert Web Development",
    subtitle: "Crafting digital experiences that captivate and convert."
  },
  {
    image: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=1920&h=1080&fit=crop",
    title: "Strategic SEO & Marketing",
    subtitle: "Drive growth with data-driven strategies."
  }
];

export default function HeroCarousel() {
  const [emblaRef] = useEmblaCarousel({ loop: true }, [Autoplay({ delay: 5000 })]);

  return (
    <div className="relative overflow-hidden bg-black" ref={emblaRef}>
      <div className="flex">
        {SLIDES.map((slide, index) => (
          <div key={index} className="relative flex-[0_0_100%] min-w-0 h-[600px] md:h-[800px]">
            {/* Background Image */}
            <div 
              className="absolute inset-0 bg-cover bg-center transition-transform duration-1000 hover:scale-105"
              style={{ backgroundImage: `url(${slide.image})` }}
            />
            {/* Overlay */}
            <div className="absolute inset-0 bg-black/40" />
            
            {/* Content */}
            <div className="absolute inset-0 flex items-center justify-center text-center px-4">
              <div className="max-w-4xl space-y-6 animate-in fade-in slide-in-from-bottom-8 duration-700">
                <h1 className="text-4xl md:text-7xl font-display font-bold text-white tracking-tight leading-tight">
                  {slide.title}
                </h1>
                <p className="text-lg md:text-2xl text-gray-200 font-light max-w-2xl mx-auto">
                  {slide.subtitle}
                </p>
                <div className="pt-8">
                  <a href="#services">
                    <Button size="lg" className="rounded-full px-8 py-6 text-lg bg-primary hover:bg-primary/90 text-black font-semibold">
                      Explore Services
                    </Button>
                  </a>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
