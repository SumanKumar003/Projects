import { Link } from "wouter";
import { Facebook, Twitter, Instagram, Mail, Phone, MapPin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-secondary text-secondary-foreground pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-2xl font-display font-bold text-primary">KURIA POOL</h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              Premium freelance services tailored for excellence. We connect talent with opportunity in the most sophisticated way.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-display font-bold text-lg">Quick Links</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="/#services" className="hover:text-primary transition-colors">Services</a></li>
              <li><a href="/#about" className="hover:text-primary transition-colors">About Us</a></li>
              <li><Link href="/login" className="hover:text-primary transition-colors">Login</Link></li>
            </ul>
          </div>

          {/* Support */}
          <div className="space-y-4">
            <h4 className="font-display font-bold text-lg">Support</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="/#contact" className="hover:text-primary transition-colors">Contact Support</a></li>
              <li><span className="cursor-pointer hover:text-primary transition-colors">Careers</span></li>
              <li><span className="cursor-pointer hover:text-primary transition-colors">Privacy Policy</span></li>
              <li><span className="cursor-pointer hover:text-primary transition-colors">Terms of Service</span></li>
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h4 className="font-display font-bold text-lg">Contact Us</h4>
            <div className="space-y-3 text-sm text-gray-400">
              <div className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-primary" />
                <span>support@kuriapool.com</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-primary" />
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="h-4 w-4 text-primary" />
                <span>123 Fashion Ave, NY</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-gray-500">© 2025 Kuria Pool. All rights reserved.</p>
          <div className="flex gap-4">
            <Facebook className="h-5 w-5 text-gray-400 hover:text-primary cursor-pointer transition-colors" />
            <Twitter className="h-5 w-5 text-gray-400 hover:text-primary cursor-pointer transition-colors" />
            <Instagram className="h-5 w-5 text-gray-400 hover:text-primary cursor-pointer transition-colors" />
          </div>
        </div>
      </div>
    </footer>
  );
}
