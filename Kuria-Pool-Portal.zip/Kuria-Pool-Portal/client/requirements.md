## Packages
framer-motion | Smooth animations and page transitions
embla-carousel-react | Carousel sliders for hero and services
embla-carousel-autoplay | Autoplay plugin for carousels
date-fns | Date formatting for bookings
clsx | Class name utility
tailwind-merge | Class merging utility

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Playfair Display'", "serif"],
  body: ["'Montserrat'", "sans-serif"],
}
