import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export * from "./models/chat";

// === USERS ===
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role", { enum: ["admin", "manager", "client", "user"] }).notNull().default("user"),
  email: text("email"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

// === SERVICES ===
export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(), // In cents/paise
  imageUrl: text("image_url").notNull(),
  category: text("category").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertServiceSchema = createInsertSchema(services).omit({ id: true, createdAt: true });
export type Service = typeof services.$inferSelect;
export type InsertService = z.infer<typeof insertServiceSchema>;

// === BOOKINGS ===
export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(), // Can be null if guest? No, "user" role.
  serviceId: integer("service_id").notNull(),
  status: text("status", { enum: ["pending", "confirmed", "completed", "cancelled"] }).default("pending"),
  paymentStatus: text("payment_status", { enum: ["pending", "paid", "failed"] }).default("pending"),
  bookingDate: timestamp("booking_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertBookingSchema = createInsertSchema(bookings).omit({ id: true, createdAt: true });
export type Booking = typeof bookings.$inferSelect;
export type InsertBooking = z.infer<typeof insertBookingSchema>;

// === CLIENT CONTENT (Manager uploads for Clients) ===
export const clientContent = pgTable("client_content", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  managerId: integer("manager_id").notNull(),
  title: text("title").notNull(),
  type: text("type", { enum: ["image", "audio", "video"] }).notNull(),
  url: text("url").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertClientContentSchema = createInsertSchema(clientContent).omit({ id: true, createdAt: true });
export type ClientContent = typeof clientContent.$inferSelect;
export type InsertClientContent = z.infer<typeof insertClientContentSchema>;

// === SITE CONFIG (CMS) ===
export const siteConfig = pgTable("site_config", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(), // e.g., "header_logo", "footer_text", "seo_title"
  value: text("value").notNull(),
  type: text("type", { enum: ["text", "image", "json"] }).default("text"),
});

export const insertSiteConfigSchema = createInsertSchema(siteConfig).omit({ id: true });
export type SiteConfig = typeof siteConfig.$inferSelect;
export type InsertSiteConfig = z.infer<typeof insertSiteConfigSchema>;

// === INQUIRIES (Contact/Career) ===
export const inquiries = pgTable("inquiries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  message: text("message").notNull(),
  type: text("type", { enum: ["contact", "career"] }).default("contact"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertInquirySchema = createInsertSchema(inquiries).omit({ id: true, createdAt: true });
export type Inquiry = typeof inquiries.$inferSelect;
export type InsertInquiry = z.infer<typeof insertInquirySchema>;
