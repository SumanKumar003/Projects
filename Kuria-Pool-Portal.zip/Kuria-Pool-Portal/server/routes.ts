import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, hashPassword } from "./auth";
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerImageRoutes } from "./replit_integrations/image";
import { registerAudioRoutes } from "./replit_integrations/audio";
import { api, errorSchemas } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Authentication
  setupAuth(app);

  // Register Integration Routes
  registerChatRoutes(app);
  registerImageRoutes(app);
  registerAudioRoutes(app);

  // Middleware to check role
  const requireRole = (role: string) => (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== role && req.user.role !== 'admin') return res.status(403).json({ message: "Forbidden" });
    next();
  };

  // === Services Routes ===
  app.get(api.services.list.path, async (req, res) => {
    const services = await storage.getServices();
    res.json(services);
  });

  app.get(api.services.get.path, async (req, res) => {
    const service = await storage.getService(Number(req.params.id));
    if (!service) return res.status(404).json({ message: "Service not found" });
    res.json(service);
  });

  app.post(api.services.create.path, requireRole('admin'), async (req, res) => {
    try {
      const input = api.services.create.input.parse(req.body);
      const service = await storage.createService(input);
      res.status(201).json(service);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.put(api.services.update.path, requireRole('admin'), async (req, res) => {
    try {
      const input = api.services.update.input.parse(req.body);
      const service = await storage.updateService(Number(req.params.id), input);
      if (!service) return res.status(404).json({ message: "Service not found" });
      res.json(service);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.delete(api.services.delete.path, requireRole('admin'), async (req, res) => {
    await storage.deleteService(Number(req.params.id));
    res.sendStatus(204);
  });

  // === Bookings Routes ===
  app.get(api.bookings.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role === 'admin' || req.user.role === 'manager') {
      const bookings = await storage.getBookings();
      res.json(bookings);
    } else {
      const bookings = await storage.getBookingsByUser(req.user.id);
      res.json(bookings);
    }
  });

  app.post(api.bookings.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    try {
      const input = api.bookings.create.input.parse(req.body);
      // Force userId to current user if not admin
      const bookingData = { ...input, userId: req.user.id };
      const booking = await storage.createBooking(bookingData);
      res.status(201).json(booking);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.put(api.bookings.update.path, requireRole('manager'), async (req, res) => {
    try {
      const input = api.bookings.update.input.parse(req.body);
      const booking = await storage.updateBooking(Number(req.params.id), input);
      if (!booking) return res.status(404).json({ message: "Booking not found" });
      res.json(booking);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  // === Client Content Routes ===
  app.get(api.content.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    // Users see their own content, Managers/Admins see all? Or by query param?
    // Simplified: If user, see own content. If manager/admin and clientId param provided, see that client's content.
    const clientId = req.query.clientId ? Number(req.query.clientId) : req.user.id;
    if (req.user.role === 'user' && clientId !== req.user.id) {
       return res.status(403).json({ message: "Forbidden" });
    }
    const content = await storage.getClientContent(clientId);
    res.json(content);
  });

  app.post(api.content.create.path, requireRole('manager'), async (req, res) => {
    try {
      const input = api.content.create.input.parse(req.body);
      // Auto-assign managerId
      const contentData = { ...input, managerId: req.user.id };
      const content = await storage.createClientContent(contentData);
      
      // TODO: Send email notification to client (Stub)
      console.log(`[Email Stub] Notification sent to client ${content.clientId}: New content uploaded.`);
      
      res.status(201).json(content);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.delete(api.content.delete.path, requireRole('manager'), async (req, res) => {
    await storage.deleteClientContent(Number(req.params.id));
    res.sendStatus(204);
  });

  // === Site Config Routes ===
  app.get(api.config.list.path, async (req, res) => {
    const config = await storage.getSiteConfig();
    res.json(config);
  });

  app.post(api.config.update.path, requireRole('admin'), async (req, res) => {
    try {
      // Manual parse since input is object in routes.ts but might need specific handling
      // Actually routes.ts defined it well.
      const input = z.object({
        key: z.string(),
        value: z.string(),
        type: z.enum(["text", "image", "json"]).optional(),
      }).parse(req.body);
      
      const config = await storage.upsertSiteConfig(input);
      res.json(config);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  // === Inquiries Routes ===
  app.post(api.inquiries.create.path, async (req, res) => {
    try {
      const input = api.inquiries.create.input.parse(req.body);
      const inquiry = await storage.createInquiry(input);
      res.status(201).json(inquiry);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.get(api.inquiries.list.path, requireRole('admin'), async (req, res) => {
    const inquiries = await storage.getInquiries();
    res.json(inquiries);
  });

  // === Seed Data ===
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const adminUsername = "Suman Kumar!";
  const adminPassword = await hashPassword("SK.@Ku12!@");
  
  const existingAdmin = await storage.getUserByUsername(adminUsername);
  if (!existingAdmin) {
    await storage.createUser({
      username: adminUsername,
      password: adminPassword,
      role: "admin",
      email: "admin@kuriapool.com"
    });
    console.log("Admin user seeded.");
  }

  // Seed some services if empty
  const services = await storage.getServices();
  if (services.length === 0) {
    await storage.createService({
      title: "Web Development",
      description: "Full-stack custom website development.",
      price: 50000, // 500.00
      imageUrl: "https://images.unsplash.com/photo-1498050108023-c5249f4df085",
      category: "Development"
    });
    await storage.createService({
      title: "SEO Optimization",
      description: "Rank higher on search engines.",
      price: 30000,
      imageUrl: "https://images.unsplash.com/photo-1571721795195-a2ca2d337096",
      category: "Marketing"
    });
    await storage.createService({
      title: "Social Media Management",
      description: "Manage your social presence.",
      price: 25000,
      imageUrl: "https://images.unsplash.com/photo-1611162617474-5b21e879e113",
      category: "Marketing"
    });
  }

  // Seed Site Config
  const config = await storage.getSiteConfig();
  if (config.length === 0) {
    await storage.upsertSiteConfig({ key: "site_title", value: "Kuria Pool", type: "text" });
    await storage.upsertSiteConfig({ key: "contact_email", value: "contact@kuriapool.com", type: "text" });
    await storage.upsertSiteConfig({ key: "footer_text", value: "© 2024 Kuria Pool. All rights reserved.", type: "text" });
  }
}
