import { 
  users, services, bookings, clientContent, siteConfig, inquiries,
  type User, type InsertUser,
  type Service, type InsertService,
  type Booking, type InsertBooking,
  type ClientContent, type InsertClientContent,
  type SiteConfig, type InsertSiteConfig,
  type Inquiry, type InsertInquiry
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Services
  getServices(): Promise<Service[]>;
  getService(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: number, service: Partial<InsertService>): Promise<Service>;
  deleteService(id: number): Promise<void>;

  // Bookings
  getBookings(): Promise<Booking[]>;
  getBookingsByUser(userId: number): Promise<Booking[]>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBooking(id: number, booking: Partial<InsertBooking>): Promise<Booking>;

  // Client Content
  getClientContent(clientId: number): Promise<ClientContent[]>;
  createClientContent(content: InsertClientContent): Promise<ClientContent>;
  deleteClientContent(id: number): Promise<void>;

  // Site Config
  getSiteConfig(): Promise<SiteConfig[]>;
  upsertSiteConfig(config: InsertSiteConfig): Promise<SiteConfig>;
  getSiteConfigByKey(key: string): Promise<SiteConfig | undefined>;

  // Inquiries
  getInquiries(): Promise<Inquiry[]>;
  createInquiry(inquiry: InsertInquiry): Promise<Inquiry>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Services
  async getServices(): Promise<Service[]> {
    return await db.select().from(services).orderBy(desc(services.createdAt));
  }

  async getService(id: number): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(eq(services.id, id));
    return service;
  }

  async createService(insertService: InsertService): Promise<Service> {
    const [service] = await db.insert(services).values(insertService).returning();
    return service;
  }

  async updateService(id: number, updates: Partial<InsertService>): Promise<Service> {
    const [service] = await db.update(services).set(updates).where(eq(services.id, id)).returning();
    return service;
  }

  async deleteService(id: number): Promise<void> {
    await db.delete(services).where(eq(services.id, id));
  }

  // Bookings
  async getBookings(): Promise<Booking[]> {
    return await db.select().from(bookings).orderBy(desc(bookings.createdAt));
  }

  async getBookingsByUser(userId: number): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.userId, userId)).orderBy(desc(bookings.createdAt));
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const [booking] = await db.insert(bookings).values(insertBooking).returning();
    return booking;
  }

  async updateBooking(id: number, updates: Partial<InsertBooking>): Promise<Booking> {
    const [booking] = await db.update(bookings).set(updates).where(eq(bookings.id, id)).returning();
    return booking;
  }

  // Client Content
  async getClientContent(clientId: number): Promise<ClientContent[]> {
    return await db.select().from(clientContent).where(eq(clientContent.clientId, clientId)).orderBy(desc(clientContent.createdAt));
  }

  async createClientContent(insertContent: InsertClientContent): Promise<ClientContent> {
    const [content] = await db.insert(clientContent).values(insertContent).returning();
    return content;
  }

  async deleteClientContent(id: number): Promise<void> {
    await db.delete(clientContent).where(eq(clientContent.id, id));
  }

  // Site Config
  async getSiteConfig(): Promise<SiteConfig[]> {
    return await db.select().from(siteConfig);
  }

  async getSiteConfigByKey(key: string): Promise<SiteConfig | undefined> {
    const [config] = await db.select().from(siteConfig).where(eq(siteConfig.key, key));
    return config;
  }

  async upsertSiteConfig(insertConfig: InsertSiteConfig): Promise<SiteConfig> {
    // Try to update first, if not exists insert.
    // Drizzle doesn't have upsert for all drivers easily, but PG supports it.
    // For simplicity with basic drizzle:
    const existing = await this.getSiteConfigByKey(insertConfig.key);
    if (existing) {
        const [updated] = await db.update(siteConfig)
            .set({ value: insertConfig.value, type: insertConfig.type })
            .where(eq(siteConfig.key, insertConfig.key))
            .returning();
        return updated;
    } else {
        const [created] = await db.insert(siteConfig).values(insertConfig).returning();
        return created;
    }
  }

  // Inquiries
  async getInquiries(): Promise<Inquiry[]> {
    return await db.select().from(inquiries).orderBy(desc(inquiries.createdAt));
  }

  async createInquiry(insertInquiry: InsertInquiry): Promise<Inquiry> {
    const [inquiry] = await db.insert(inquiries).values(insertInquiry).returning();
    return inquiry;
  }
}

export const storage = new DatabaseStorage();
